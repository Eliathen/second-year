var searchData=
[
  ['prevhit',['prevHit',['../class_enemy.html#a0414974f256df3ae56424afad1b2ef8a',1,'Enemy']]]
];
