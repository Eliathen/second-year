var searchData=
[
  ['direction',['direction',['../class_player.html#a6d95202b5546ac375bdb75e3fb657d17',1,'Player']]],
  ['down',['down',['../class_enemy.html#afca5dcc6f8fe24bdf849386a2ff5ec99',1,'Enemy']]]
];
