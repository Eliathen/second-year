var searchData=
[
  ['fieldsstatus',['fieldsStatus',['../class_map.html#a33e0f6344dd6a5a88edf8787074d1873',1,'Map']]],
  ['fire',['FIRE',['../player_8hpp.html#adf764cbdea00d65edcd07bb9953ad2b7a6811f08ec3a763b0351fab6fb5054df8',1,'player.hpp']]],
  ['firstshootx',['firstShootX',['../class_enemy.html#a4f53e48f14dcd4040508e835cc16795e',1,'Enemy']]],
  ['firstshooty',['firstShootY',['../class_enemy.html#ad80171d33830afb114fdb4686842f6a9',1,'Enemy']]]
];
