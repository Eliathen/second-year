var searchData=
[
  ['ispossible',['isPossible',['../class_player.html#a424ff0092042cbf5a0dc4a3eed206cf3',1,'Player']]],
  ['isselected',['isSelected',['../class_player.html#a816d13e8416776b12a45b2ac5df44052',1,'Player']]]
];
