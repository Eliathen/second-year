var searchData=
[
  ['up',['up',['../class_enemy.html#a8e9072b14a645efe184dd5fe1d237d57',1,'Enemy']]]
];
