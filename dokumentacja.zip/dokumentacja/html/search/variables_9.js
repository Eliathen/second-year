var searchData=
[
  ['right',['right',['../class_enemy.html#a37d605a30cf2e4978ef2cff18fadf896',1,'Enemy']]]
];
