var searchData=
[
  ['setmenuoptions',['setMenuOptions',['../class_game.html#a96771cd0fd09eabbfe3d2c7071751979',1,'Game']]],
  ['setname',['setName',['../class_player.html#a95d2b46eee230ad3e31612ff2bc681da',1,'Player']]],
  ['setresult',['setResult',['../class_game.html#a227f0f6275900384cf0a8bd023492ac5',1,'Game']]],
  ['setshipusingxandy',['setShipUsingXandY',['../class_map.html#a453b655fd0ab5e7d744b47f229d5628b',1,'Map']]],
  ['shootdown',['shootDown',['../class_enemy.html#a2efad921c75d05f771b9adb3f059d404',1,'Enemy']]],
  ['shootleft',['shootLeft',['../class_enemy.html#aece24edd11b0135d5f5c43a912e25c3b',1,'Enemy']]],
  ['shootright',['shootRight',['../class_enemy.html#a365cd50ab71fd2b010be5b5406911557',1,'Enemy']]],
  ['shootup',['shootUp',['../class_enemy.html#ac8d99cfc1cc426812c02ef4e13b73db0',1,'Enemy']]],
  ['showgame',['showGame',['../class_game.html#a4add87dc3562eaec48950be1b60b4bcb',1,'Game::showGame(sf::Sprite gameBackground)'],['../class_game.html#a94caca0c99a6f42ad9e1c92f137fd326',1,'Game::showGame(sf::Sprite gameBackground, sf::Sprite reset)']]],
  ['showgameduringstaticspread',['showGameDuringStaticSpread',['../class_game.html#a3ad51034e213fa26959b93ad9f172a09',1,'Game']]],
  ['showinstruction',['showInstruction',['../class_game.html#a628675eaa43963267baba8603e50e376',1,'Game']]],
  ['showmenu',['showMenu',['../class_game.html#ae1130cb91d6aa3f841772e3671d88770',1,'Game']]],
  ['startgame',['startGame',['../class_game.html#ae8638ccdb0ef3bf39a6affa30aa1258f',1,'Game']]]
];
