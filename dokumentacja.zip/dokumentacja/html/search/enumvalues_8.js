var searchData=
[
  ['spread',['SPREAD',['../player_8hpp.html#adf764cbdea00d65edcd07bb9953ad2b7aaae01bffda9e4c93e0d5ecc0481906ec',1,'player.hpp']]],
  ['staticspread',['staticSpread',['../game_8hpp.html#a905479d79c2aa8410d2fc374bc75cc5baeac9136a271f518e3f3b2d76fbe4b3d8',1,'game.hpp']]]
];
