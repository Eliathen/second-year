var searchData=
[
  ['newgame',['newGame',['../class_game.html#a12f32ba70a35a0dcd1f527b4d4a0d2c4',1,'Game']]]
];
