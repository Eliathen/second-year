var searchData=
[
  ['name',['name',['../class_map.html#a1b1d492ae94e6ce4f76536bd33d8123c',1,'Map::name()'],['../class_player.html#af9c920fabaafdeb7961a645315b521ff',1,'Player::name()']]]
];
