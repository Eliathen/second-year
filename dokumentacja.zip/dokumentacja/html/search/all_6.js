var searchData=
[
  ['instruction',['instruction',['../game_8hpp.html#a905479d79c2aa8410d2fc374bc75cc5ba3600a8e6a8c38b159c017f9441676aa4',1,'game.hpp']]],
  ['ispossible',['isPossible',['../class_player.html#a424ff0092042cbf5a0dc4a3eed206cf3',1,'Player']]],
  ['ispossibletoplace',['isPossibleToPlace',['../class_player.html#a0aeb066e0f8b2994589a7b263870e4e1',1,'Player']]],
  ['isselected',['isSelected',['../class_player.html#a816d13e8416776b12a45b2ac5df44052',1,'Player']]]
];
