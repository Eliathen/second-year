var searchData=
[
  ['shootx',['shootX',['../class_enemy.html#aa0c062438f0ac2e4b54ba3e89ed23812',1,'Enemy']]],
  ['shooty',['shootY',['../class_enemy.html#a97f3fd794822fe661f9eba4b4652bc78',1,'Enemy']]]
];
