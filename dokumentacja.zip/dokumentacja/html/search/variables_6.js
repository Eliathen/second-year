var searchData=
[
  ['mode',['mode',['../class_player.html#aa8a368e97461d92ac42b0d7590ebd4d8',1,'Player']]]
];
