var searchData=
[
  ['resetallships',['resetAllShips',['../class_player.html#aacc94dbf9eddff1ead1621393dda7f43',1,'Player']]],
  ['resetlifepoints',['resetLifePoints',['../class_enemy.html#ac0d941351eef95adb11ef4239ce0c45f',1,'Enemy::resetLifePoints()'],['../class_player.html#abcc05a35ee99e2dad68f98a7b262becb',1,'Player::resetLifePoints()']]]
];
