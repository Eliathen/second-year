var searchData=
[
  ['game',['Game',['../class_game.html#ad59df6562a58a614fda24622d3715b65',1,'Game']]],
  ['getcoordinate',['getCoordinate',['../class_player.html#a2e7622e0b1348dde863b77003c21a834',1,'Player']]]
];
