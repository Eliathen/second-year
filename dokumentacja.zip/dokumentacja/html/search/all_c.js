var searchData=
[
  ['resetallships',['resetAllShips',['../class_player.html#aacc94dbf9eddff1ead1621393dda7f43',1,'Player']]],
  ['resetlifepoints',['resetLifePoints',['../class_enemy.html#ac0d941351eef95adb11ef4239ce0c45f',1,'Enemy::resetLifePoints()'],['../class_player.html#abcc05a35ee99e2dad68f98a7b262becb',1,'Player::resetLifePoints()']]],
  ['right',['right',['../class_enemy.html#a37d605a30cf2e4978ef2cff18fadf896',1,'Enemy::right()'],['../map_8hpp.html#a06fc87d81c62e9abb8790b6e5713c55baec8379af7490bb9eaaf579cf17876f38',1,'RIGHT():&#160;map.hpp']]]
];
