var searchData=
[
  ['name',['name',['../class_map.html#a1b1d492ae94e6ce4f76536bd33d8123c',1,'Map::name()'],['../class_player.html#af9c920fabaafdeb7961a645315b521ff',1,'Player::name()']]],
  ['newgame',['newGame',['../class_game.html#a12f32ba70a35a0dcd1f527b4d4a0d2c4',1,'Game']]]
];
